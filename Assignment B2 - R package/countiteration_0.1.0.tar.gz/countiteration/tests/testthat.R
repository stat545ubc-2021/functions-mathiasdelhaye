library(testthat)
library(countiteration)

test_check("countiteration")
